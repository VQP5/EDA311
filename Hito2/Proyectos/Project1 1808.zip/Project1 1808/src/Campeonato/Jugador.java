package Campeonato;

import java.sql.SQLOutput;

public class Jugador {

    private String nombreCompleto;
    private String apellidos;
    private String ci;
    private int edad;

    public Jugador(String nombreCompleto, String apellidos, String ci, int edad) {
        this.nombreCompleto = nombreCompleto;
        this.apellidos = apellidos;
        this.ci = ci;
        this.edad = edad;
    }

    public String getNombreCompleto() {
        return this.nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public String getApellidos() {
        return this.apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getCi() {
        return this.ci;
    }

    public void setCi(String ci) {
        this.ci = ci;
    }

    public int getEdad() {
        return this.edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void mostrarJugador() {
        System.out.println("\nMOSTRANDO DATOS DEL JUGADOR");
        System.out.println("Nombre Jugador: " + this.getNombreCompleto());
        System.out.println("Apellidos Jugador: " + this.getApellidos());
        System.out.println("CI Jugador: " + this.getCi());
        System.out.println("Edad Jugador: " + this.getEdad());
    }
}
