package Campeonato;

import java.util.Scanner;

public class Main3 {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);

        System.out.println("INGRESE DATOS DE JUGADORES");
        String nombreCompleto, apellidos, ci;
        int edad, numeroJugadores = 3;

        Jugador jugadores[] = new Jugador[numeroJugadores];

        for (int i=0; i<numeroJugadores; i=i+1) {
            System.out.print("Ingrese nombre del Jugador " + (i+1) + ": ");
            nombreCompleto = leer.next();
            System.out.print("Ingrese apellidos del Jugador " + (i+1) + ": ");
            apellidos = leer.next();
            System.out.print("Ingrese CI del Jugador " + (i+1) + ": ");
            ci = leer.next();
            System.out.print("Ingrese edad del Jugador " + (i+1) + ": ");
            edad = leer.nextInt();

            Jugador jug = new Jugador();
            jug.setNombreCompleto(nombreCompleto);
            jug.setApellidos(apellidos);
            jug.setCi(ci);
            jug.setEdad(edad);

            jugadores[i] = jug;

            System.out.println("");
        }

        Equipo eq1 = new Equipo("Always Ready", "Varones", jugadores);
        eq1.mostrarEquipo();

        // Crear un campeonato  de nombre UNIFRANZITOS
        // Este campeonato debe tener inscritos dos equipos
        // Lso equipos podrían ser: Always Ready y El Alto FC
        // Y cada equipo tiene que tener 3 jugadprse
        // NOTA: Todos los valores deben ser leídos desde consola
        // NOTA2: Evitar duplicar código, considere el uso de Bucles

    }

}
