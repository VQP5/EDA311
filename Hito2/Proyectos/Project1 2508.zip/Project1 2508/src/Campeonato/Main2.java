package Campeonato;

import java.util.Scanner;

public class Main2 {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        System.out.println("INGRESE DATOS DE JUGADORES");

        String nombreCompleto1, apellidos1, ci1;
        int edad1;
        System.out.print("Ingrese nombre del Jugador 1: ");
        nombreCompleto1 = leer.next();
        System.out.print("Ingrese apellidos del Jugador 1: ");
        apellidos1 = leer.next();
        System.out.print("Ingrese CI del Jugador 1: ");
        ci1 = leer.next();
        System.out.print("Ingrese edad del Jugador 1: ");
        edad1 = leer.nextInt();

        //Jugador jug1 = new Jugador(nombreCompleto1, apellidos1, ci1, edad1);
        //jug1.mostrarJugador();

        Jugador jug1 = new Jugador();
        jug1.setNombreCompleto(nombreCompleto1);
        jug1.setApellidos(apellidos1);
        jug1.setCi(ci1);
        jug1.setEdad(edad1);

        jug1.mostrarJugador();

        String nombreCompleto2, apellidos2, ci2;
        int edad2;
        System.out.print("Ingrese nombre del Jugador 2: ");
        nombreCompleto2 = leer.next();
        System.out.print("Ingrese apellidos del Jugador 2: ");
        apellidos2 = leer.next();
        System.out.print("Ingrese CI del Jugador 2: ");
        ci2 = leer.next();
        System.out.print("Ingrese edad del Jugador 2: ");
        edad2 = leer.nextInt();

        //Jugador jug2 = new Jugador(nombreCompleto2, apellidos2, ci2, edad2);
        //jug2.mostrarJugador();

        Jugador jug2 = new Jugador();
        jug2.setNombreCompleto(nombreCompleto2);
        jug2.setApellidos(apellidos2);
        jug2.setCi(ci2);
        jug2.setEdad(edad2);

        jug2.mostrarJugador();


    }

}
