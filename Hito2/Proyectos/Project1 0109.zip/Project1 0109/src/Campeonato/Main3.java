package Campeonato;

import java.util.Scanner;

public class Main3 {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        String nombreCompleto, apellidos, ci;
        int edad, numeroJugadores = 2, numeroEquipos=2;

        String nombreEquipo, categoriaEquipo, nombreCampeonato;
        int  nCampeonatos = 2, nEquipos = 2;

        for (int k=0; k<nCampeonatos; k=k+1) {
            System.out.println("INGRESE DATOS DEL CAMPEONATO");
            System.out.print("Ingrese nombre del Campeonato " + (k+1) + ": ");
            nombreCampeonato = leer.next();
            Equipo equipos[] = new Equipo[numeroEquipos];

            System.out.println("");
            System.out.println("INGRESE DATOS DEl EQUIPO DEL CAMPEONATO " + nombreCampeonato);

            for (int j=0; j<nEquipos; j=j+1) {
                System.out.println("INGRESE DATOS DEL EQUIPO");
                System.out.print("Ingrese nombre del Equipo " + (j+1) + ": ");
                nombreEquipo = leer.next();
                System.out.print("Ingrese categoria del Equipo " + (j+1) + ": ");
                categoriaEquipo = leer.next();
                Jugador jugadores[] = new Jugador[numeroJugadores];

                System.out.println("");
                System.out.println("INGRESE DATOS DE JUGADORES DEL EQUIPO " + nombreEquipo);

                for (int i=0; i<numeroJugadores; i=i+1) {
                    System.out.print("Ingrese nombre del Jugador " + (i+1) + ": ");
                    nombreCompleto = leer.next();
                    System.out.print("Ingrese apellidos del Jugador " + (i+1) + ": ");
                    apellidos = leer.next();
                    System.out.print("Ingrese CI del Jugador " + (i+1) + ": ");
                    ci = leer.next();
                    System.out.print("Ingrese edad del Jugador " + (i+1) + ": ");
                    edad = leer.nextInt();

                    Jugador jug = new Jugador();
                    jug.setNombreCompleto(nombreCompleto);
                    jug.setApellidos(apellidos);
                    jug.setCi(ci);
                    jug.setEdad(edad);

                    jugadores[i] = jug;

                    System.out.println("");
                }

                Equipo eq = new Equipo();
                eq.setNombreEquipo(nombreEquipo);
                eq.setCategoria(categoriaEquipo);
                eq.setJugadores(jugadores);

                equipos[j] = eq;
                System.out.println("");
            }

            Campeonato c = new Campeonato();
            c.setNombreCampeonato(nombreCampeonato);
            c.setEquipos(equipos);
            c.mostrarCampeonato();

            System.out.println("");
        }

    }

    // Crear un campeonato  de nombre UNIFRANZITOS
    // Este campeonato debe tener inscritos dos equipos
    // Lso equipos podrían ser: Always Ready y El Alto FC
    // Y cada equipo tiene que tener 3 jugadprse
    // NOTA: Todos los valores deben ser leídos desde consola
    // NOTA2: Evitar duplicar código, considere el uso de Bucles

    // AÑADIR LOS VECTORES DE CAMPEONATO
}
