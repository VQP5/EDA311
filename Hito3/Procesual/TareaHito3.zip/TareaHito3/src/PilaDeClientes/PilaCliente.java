package PilaDeClientes;

public class PilaCliente {

    private int max;
    private Cliente[] clientes;
    private int tope;

    public PilaCliente(int max) {
        this.tope = 0;
        this.max = max;
        this.clientes = new Cliente[this.max + 1];
    }

    public boolean esVacio() {
        if(tope == 0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean esllena() {
        if(tope == max) {
            return true;
        } else {
            return false;
        }
    }

    public int nroeElem() {
        return this.tope;
    }

    public void adicionar(Cliente nuevoCliente) {
        if(this.esllena() == false) {
            this.tope = this.tope + 1;
            this.clientes[this.tope] = nuevoCliente;
        } else {
            System.out.println("La Pila de Clientes esta llena.");
        }
    }

    public Cliente eliminar() {
        Cliente elementoEliminado = null;
        if(this.esVacio() == false) {
            elementoEliminado = this.clientes[this.tope];
            this.tope = this.tope - 1;
        } else {
            System.out.println("La Pila de Clientes esta vacia.");
        }
        return elementoEliminado;
    }

    public void llenar() {

    }

    public void mostrar() {
        Cliente elem = null;
        if(this.esVacio() == true) {
            System.out.println("La Pila de Clientes esta vacia.");
        } else {
            System.out.println("\nMostrando la Pila de Clientes");
            PilaCliente aux = new PilaCliente(this.max);
            while(this.esVacio() == false) {
                elem = this.eliminar();
                aux.adicionar(elem);
                elem.muestraCliente();
            }
            vaciar(aux);
        }
    }

    public void vaciar (PilaCliente a) {
        while(a.esVacio() == false){
            adicionar(a.eliminar());
        }
    }

}
