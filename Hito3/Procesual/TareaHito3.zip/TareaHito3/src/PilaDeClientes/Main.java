package PilaDeClientes;

public class Main {

    public static void main(String[] args) {

        Cliente cli1 = new Cliente("Sebastian", "Bilbao", 25, "Drew Plains", "Masculino");
        Cliente cli2 = new Cliente("Patricia", "Herrera", 21, "Stokes Plain", "Femenino");
        Cliente cli3 = new Cliente("Roberto", "Espinosa", 18, "Hal Village", "Masculino");
        Cliente cli4 = new Cliente("Mayra", "Ramos", 12, "Zelma Lake", "Femenino");
        Cliente cli5 = new Cliente("Hugo", "Torrico", 27, "Donnelly Square", "Masculino");

        PilaCliente pilaCli = new PilaCliente(5);
        pilaCli.adicionar(cli1);
        pilaCli.adicionar(cli2);
        pilaCli.adicionar(cli3);
        pilaCli.adicionar(cli4);
        pilaCli.adicionar(cli5);

        //pilaCli.mostrar();
        //mayoresCiertaEdad(pilaCli,20);
        //kEsimoPosicion(pilaCli,3);
        //asignaDireccion(pilaCli,"Nueva Dirección");
        //reordenaPila(pilaCli);
    }

    public static void mayoresCiertaEdad(PilaCliente Pila, int edadMayor) {

        PilaCliente aux = new PilaCliente(5);
        int contador = 0;
        Cliente valorExtraidoDeLaPila = null;
        while(Pila.esVacio() == false) {
            valorExtraidoDeLaPila = Pila.eliminar();
            if(valorExtraidoDeLaPila.getEdad() > edadMayor) {
                contador = contador + 1;
            }
            aux.adicionar(valorExtraidoDeLaPila);
        }
        Pila.vaciar(aux);
        System.out.println("\nCantidad de Clientes mayores de 20 años: " + contador);

    }

    public static void kEsimoPosicion(PilaCliente Pila, int valorTope) {

        PilaCliente aux = new PilaCliente(5);
        PilaCliente aux2 = new PilaCliente(1);
        Cliente valorExtraidoDeLaPila = null;
        while (Pila.esVacio() == false) {
            if (Pila.nroeElem() != valorTope) {
                valorExtraidoDeLaPila = Pila.eliminar();
                aux.adicionar(valorExtraidoDeLaPila);
            }else{
                valorExtraidoDeLaPila = Pila.eliminar();
                aux2.adicionar(valorExtraidoDeLaPila);
            }
        }
        Pila.vaciar(aux);
        Pila.vaciar(aux2);
        Pila.mostrar();

    }

    public static void asignaDireccion(PilaCliente Pila, String nuevaDireccion) {

        PilaCliente aux = new PilaCliente(5);
        Cliente valorExtraidoDeLaPila = null;
        while (Pila.esVacio() == false) {
            valorExtraidoDeLaPila = Pila.eliminar();
            if(valorExtraidoDeLaPila.getGenero().equals("Femenino")) {
                valorExtraidoDeLaPila.setDireccion(nuevaDireccion);
            }
            aux.adicionar(valorExtraidoDeLaPila);
        }
        Pila.vaciar(aux);
        Pila.mostrar();

    }

    public static void reordenaPila(PilaCliente Pila) {

        PilaCliente aux = new PilaCliente(5);
        PilaCliente aux2 = new PilaCliente(5);
        Cliente valorExtraidoDeLaPila = null;
        while (Pila.esVacio() == false) {
            valorExtraidoDeLaPila = Pila.eliminar();
            if(valorExtraidoDeLaPila.getGenero().equals("Femenino")) {
                aux.adicionar(valorExtraidoDeLaPila);
            }else{
                aux2.adicionar(valorExtraidoDeLaPila);
            }
        }
        Pila.vaciar(aux2);
        Pila.vaciar(aux);
        Pila.mostrar();

    }

}
