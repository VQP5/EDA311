package Campeonato;

public class Main {

    public static void main(String[] args) {

        Jugador jug1 = new Jugador("Raul", "Conde Blanco", "12548369LP",24);
        Jugador jug2 = new Jugador("Pepe", "Pérez Ortega", "12635214LP", 25);

        Jugador[] jugadores = new Jugador[2];
        jugadores[0] = jug1;
        jugadores[1] = jug2;

        Equipo eq1 = new Equipo("Real El Alto","Varones", jugadores);
        //eq1.mostrarEquipo();

        Equipo[] equipos = new Equipo[1];
        equipos[0] = eq1;
        Campeonato c1 = new Campeonato("Tour Play", equipos);
        c1.mostrarCampeonato();

    }

}
