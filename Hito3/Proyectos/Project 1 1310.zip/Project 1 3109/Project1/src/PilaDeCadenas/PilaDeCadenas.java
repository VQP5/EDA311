package PilaDeCadenas;

import Hito3.PilaNumeros;

public class PilaDeCadenas {

    private int max;
    private String[] Nombres;
    private int tope;

    public PilaDeCadenas(int max) {
        this.tope = 0;
        this.max =max;
        Nombres = new String[this.max + 1];
    }

    public boolean esVacio() {
        if(tope == 0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean esllena() {
        if(tope == max) {
            return true;
        } else {
            return false;
        }
    }

    public int nroeElem() {
        return this.tope;
    }

    public void adicionar(String nuevoItem) {
        if(this.esllena() == false) {
            this.tope = this.tope + 1;
            this.Nombres[this.tope] = nuevoItem;
        } else {
            System.out.println("La Pila de cadenas esta llena.");
        }
    }

    public String eliminar() {
        String elementoEliminado ="";
        if(this.esVacio() == false) {
            elementoEliminado = this.Nombres[this.tope];
            this.tope = this.tope - 1;
        } else {
            System.out.println("La Pila de cadenas esta vacia.");
        }
        return elementoEliminado;
    }

    public void llenar() {

    }

    public void mostrar() {
        String elem = "";
        if(this.esVacio() == true) {
            System.out.println("La Pila de numeros esta vacia.");
        } else {
            System.out.println("Datos de la Pila ");
            PilaDeCadenas aux = new PilaDeCadenas(this.max);
            while(this.esVacio() == false) {
                elem = this.eliminar();
                aux.adicionar(elem);
                System.out.println("Elem: " + elem);
            }
            vaciar(aux);
        }
    }

    public void vaciar (PilaDeCadenas a) {
        while(a.esVacio() == false){
            adicionar(a.eliminar());
        }
    }

}
