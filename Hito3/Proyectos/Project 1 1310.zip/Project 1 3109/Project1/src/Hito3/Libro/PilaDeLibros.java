package Hito3.Libro;

public class PilaDeLibros {

    private int max;
    private Libro[] libros;
    private int tope;

    public PilaDeLibros(int max) {
        this.tope = 0;
        this.max =max;
        this.libros = new Libro[this.max + 1];
    }

    public boolean esVacio() {
        if(tope == 0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean esllena() {
        if(tope == max) {
            return true;
        } else {
            return false;
        }
    }

    public int nroeElem() {
        return this.tope;
    }

    public void adicionar(Libro nuevoLibro) {
        if(this.esllena() == false) {
            this.tope = this.tope + 1;
            this.libros[this.tope] = nuevoLibro;
        } else {
            System.out.println("La Pila de Libros esta llena.");
        }
    }

    public Libro eliminar() {
        Libro elementoEliminado = null;
        if(this.esVacio() == false) {
            elementoEliminado = this.libros[this.tope];
            this.tope = this.tope - 1;
        } else {
            System.out.println("La Pila de Libros esta vacia.");
        }
        return elementoEliminado;
    }

    public void llenar() {

    }

    public void mostrar() {
        Libro elem = null;
        if(this.esVacio() == true) {
            System.out.println("La Pila de Libros esta vacia.");
        } else {
            System.out.println("Mostrando la Pila de Libros");
            PilaDeLibros aux = new PilaDeLibros(this.max);
            while(this.esVacio() == false) {
                elem = this.eliminar();
                aux.adicionar(elem);
                elem.mostrarLibro();
            }
            vaciar(aux);
        }
    }

    public void vaciar (PilaDeLibros a) {
        while(a.esVacio() == false){
            adicionar(a.eliminar());
        }
    }
}
