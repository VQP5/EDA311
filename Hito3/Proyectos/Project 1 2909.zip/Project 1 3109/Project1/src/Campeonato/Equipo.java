package Campeonato;

public class Equipo {

    private String nombreEquipo;
    private String categoria;
    private Jugador[] jugadores;

    public Equipo(String nombreEquipo, String categoria, Jugador[] jugadores) {
        this.nombreEquipo = nombreEquipo;
        this.categoria = categoria;
        this.jugadores = jugadores;
    }

    public Equipo() {
        this.nombreEquipo = "";
        this.categoria = "";
    }

    public String getNombreEquipo() {
        return this.nombreEquipo;
    }

    public void setNombreEquipo(String nombreEquipo) {
        this.nombreEquipo = nombreEquipo;
    }

    public String getCategoria() {
        return this.categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public Jugador[] getJugadores() {
        return this.jugadores;
    }

    public void setJugadores(Jugador[] jugadores) {
        this.jugadores = jugadores;
    }

    public void mostrarEquipo() {
        System.out.println("\nMOSTRANDO DATOS DE EQUIPO");
        System.out.println("Nombre Equipo: " + this.getNombreEquipo());
        System.out.println("Categoria Equipo: " + this.getCategoria());
        for (int i=0; i<this.getJugadores().length; i=i+1) {
            this.getJugadores()[i].mostrarJugador();
        }
    }
}
