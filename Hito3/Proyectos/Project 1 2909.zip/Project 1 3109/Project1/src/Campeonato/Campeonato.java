package Campeonato;

public class Campeonato {

    private String nombreCampeonato;
    private Equipo[] equipos;

    public Campeonato(String nombreCampeonato, Equipo[] equipos) {
        this.nombreCampeonato = nombreCampeonato;
        this.equipos = equipos;
    }

    public Campeonato() {
        this.nombreCampeonato = "";
    }

    public String getNombreCampeonato() {
        return this.nombreCampeonato;
    }

    public void setNombreCampeonato(String nombreCampeonato) {
        this.nombreCampeonato = nombreCampeonato;
    }

    public Equipo[] getEquipos() {
        return this.equipos;
    }

    public void setEquipos(Equipo[] equipos) {
        this.equipos = equipos;
    }

    public void mostrarCampeonato() {
        System.out.println("\nMOSTRANDO DATOS DEL CAMPEONATO");
        System.out.println("Nombre Campeonato: " + this.getNombreCampeonato());
        for (int i=0; i<2; i=i+1) {
            this.getEquipos()[i].mostrarEquipo();
        }
    }
}
