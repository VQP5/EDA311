package defensa_pilas_hito3;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {


        Estudiante Est1 = new Estudiante("Jose", "Flores", 20, "El Alto", 30, "12572837LP");
        Estudiante Est2 = new Estudiante("Andres", "Ticona", 25, "La Paz", 40, "12572837LP");
        Estudiante Est3 = new Estudiante("Victor", "Quispe", 30, "Santa Cruz", 60, "12572837SC");
        Estudiante Est4 = new Estudiante("Ramiro", "Ruiz", 40, "El Alto", 70, "12572837OR");
        Estudiante Est5 = new Estudiante("Luis", "Pari", 60, "El Alto", 20, "12572837CH");

        PilaDeEstudiantes pilaEst = new PilaDeEstudiantes(5);

        pilaEst.adicionar(Est1);
        pilaEst.adicionar(Est2);
        pilaEst.adicionar(Est3);
        pilaEst.adicionar(Est4);
        pilaEst.adicionar(Est5);

        //pilaEst.mostrar();
        //aprobadosElAlto(pilaEst, "El Alto");
        //nuevaPosicion(pilaEst, 1);
        //nuevaPosicion(pilaEst,2);
        //menorNota(pilaEst);
        //aprobadosElAlto2(pilaEst, "El Alto");

    }

    public static void aprobadosElAlto(PilaDeEstudiantes pilaEst, String sede) {
        PilaDeEstudiantes aux = new PilaDeEstudiantes(10);
        int contar = 0;
        Estudiante valorExtraidoDeLaPila = null;

        while(pilaEst.esVacio() == false) {
            valorExtraidoDeLaPila = pilaEst.eliminar();
            if(valorExtraidoDeLaPila.getNotaFinal() > 50) {
                if(valorExtraidoDeLaPila.getSede().equals(sede)){
                    contar = contar + 1;
                }
            }
            aux.adicionar(valorExtraidoDeLaPila);
        }
        pilaEst.vaciar(aux);
        System.out.println("\nCantidad de Estudiantes aprobados en EL Alto " + contar);
    }

    public static void nuevaPosicion(PilaDeEstudiantes pilaEst, int tope){
        PilaDeEstudiantes aux = new PilaDeEstudiantes(10);
        PilaDeEstudiantes aux2 = new PilaDeEstudiantes(1);
        Estudiante valorExtraidoDeLaPila = null;
        int valor = 5;
        while(pilaEst.esVacio() == false) {
            valorExtraidoDeLaPila = pilaEst.eliminar();
            if(valor!=tope) {
                aux.adicionar(valorExtraidoDeLaPila);
            }
            else{
                aux2.adicionar(valorExtraidoDeLaPila);
            }
            valor = valor-1;
        }
        pilaEst.vaciar(aux);;
        pilaEst.vaciar(aux2);
        pilaEst.mostrar();
    }

    public static void menorNota(PilaDeEstudiantes pilaEst) {

    }

    public static void aprobadosElAlto2(PilaDeEstudiantes pilaEst, String sede) {
        PilaDeEstudiantes aux = new PilaDeEstudiantes(10);
        PilaDeEstudiantes aux2 = new PilaDeEstudiantes(10);
        Estudiante valorExtraidoDeLaPila = null;

        while(pilaEst.esVacio() == false) {
            valorExtraidoDeLaPila = pilaEst.eliminar();
            if(valorExtraidoDeLaPila.getNotaFinal() > 50) {
                if(valorExtraidoDeLaPila.getSede().equals(sede)){
                    aux2.adicionar(valorExtraidoDeLaPila);
                }
            }
            aux.adicionar(valorExtraidoDeLaPila);
        }
        pilaEst.vaciar(aux);
        aux2.mostrar();
    }
}
