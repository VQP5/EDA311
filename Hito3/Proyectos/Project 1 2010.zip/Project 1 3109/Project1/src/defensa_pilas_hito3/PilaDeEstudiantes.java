package defensa_pilas_hito3;

public class PilaDeEstudiantes {

    private int max;
    private Estudiante[] libros;
    private int tope;

    public PilaDeEstudiantes(int max) {
        this.tope = 0;
        this.max =max;
        this.libros = new Estudiante[this.max + 1];
    }

    public boolean esVacio() {
        if(tope == 0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean esllena() {
        if(tope == max) {
            return true;
        } else {
            return false;
        }
    }

    public int nroeElem() {
        return this.tope;
    }

    public void adicionar(Estudiante nuevoEstudiante) {
        if(this.esllena() == false) {
            this.tope = this.tope + 1;
            this.libros[this.tope] = nuevoEstudiante;
        } else {
            System.out.println("La Pila de Estudiantes esta llena.");
        }
    }

    public Estudiante eliminar() {
        Estudiante elementoEliminado = null;
        if(this.esVacio() == false) {
            elementoEliminado = this.libros[this.tope];
            this.tope = this.tope - 1;
        } else {
            System.out.println("La Pila de Estudiantes esta vacia.");
        }
        return elementoEliminado;
    }

    public void llenar() {

    }

    public void mostrar() {
        Estudiante elem = null;
        if(this.esVacio() == true) {
            System.out.println("La Pila de Estudiantes esta vacia.");
        } else {
            System.out.println("\nMostrando la Pila de Estudiantes");
            PilaDeEstudiantes aux = new PilaDeEstudiantes(this.max);
            while(this.esVacio() == false) {
                elem = this.eliminar();
                aux.adicionar(elem);
                elem.muestraEstudiante();
            }
            vaciar(aux);
        }
    }

    public void vaciar (PilaDeEstudiantes a) {
        while(a.esVacio() == false){
            adicionar(a.eliminar());
        }
    }

}
