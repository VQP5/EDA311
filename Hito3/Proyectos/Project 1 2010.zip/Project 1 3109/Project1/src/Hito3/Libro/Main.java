package Hito3.Libro;

import Hito3.PilaNumeros;
import PilaDeCadenas.PilaDeCadenas;

public class Main {

    public static void main(String[] args) {

        Libro lib1 = new Libro("La Odisea", "Homero", 40, 20.50, "Novela");
        Libro lib2 = new Libro("DBA I", "Saul", 50, 30.50, "Base de Datos");
        Libro lib3 = new Libro("DBA II", "Ana", 60, 40.50, "Base de Datos");
        Libro lib4 = new Libro("Proga Intro", "Micaela", 70, 55.50, "Logista");
        Libro lib5 = new Libro("Análisi y diseño", "Juan", 80, 65.50, "Analista");

        PilaDeLibros pilaLibros = new PilaDeLibros(10);
        pilaLibros.adicionar(lib1);
        pilaLibros.adicionar(lib2);
        pilaLibros.adicionar(lib3);
        pilaLibros.adicionar(lib4);
        pilaLibros.adicionar(lib5);

        //pilaLibros.mostrar();
        mayora50(pilaLibros, 50);
        //cambioSentido(pilaLibros);

    }

    //DETERMINAR CUANTOS LIBROS TIENEN UNA CANTIDAD DE PAGINAS MAYOR A 50
    public static void mayora50(PilaDeLibros pilaLibros, int pagBuscar) {
        PilaDeLibros aux = new PilaDeLibros(10);
        int contar = 0;
        Libro valorExtraidoDeLaPila = null;

        while(pilaLibros.esVacio() == false) {
            valorExtraidoDeLaPila = pilaLibros.eliminar();
            if(valorExtraidoDeLaPila.getNroPag() > pagBuscar) {
                contar = contar + 1;
            }
            aux.adicionar(valorExtraidoDeLaPila);
        }
        pilaLibros.vaciar(aux);
        System.out.println("\nCantidad de Libros con mas de " + pagBuscar + " Pags es: " + contar);
    }

    // INVERTIR LOS ITEMS EL ULTIMO AL PRINCIPIO Y EL ULTIMO AL FINAL

    public static void cambioSentido(PilaDeLibros pila) {
        PilaDeLibros aux = new PilaDeLibros(10);
        Libro ultimoLibroEliminado = pila.eliminar();
        Libro libroEliminado = null;
        Libro primerLibroEliminado = null;

        while(pila.esVacio() == false) {
            libroEliminado = pila.eliminar();
            aux.adicionar(libroEliminado);
        }

        primerLibroEliminado = aux.eliminar();
        aux.adicionar(ultimoLibroEliminado);
        pila.vaciar(aux);
        pila.adicionar(primerLibroEliminado);
        pila.mostrar();
    }

}


