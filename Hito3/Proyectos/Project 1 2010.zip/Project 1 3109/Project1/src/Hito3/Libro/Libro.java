package Hito3.Libro;

public class Libro {

    public String titulo;
    public String autor;
    public int nroPag;
    public double precio;
    public String categria;

    public Libro(String titulo, String autor, int nroPag, double precio, String categria) {
        this.titulo = titulo;
        this.autor = autor;
        this.nroPag = nroPag;
        this.precio = precio;
        this.categria = categria;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getNroPag() {
        return nroPag;
    }

    public void setNroPag(int nroPag) {
        this.nroPag = nroPag;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getCategria() {
        return categria;
    }

    public void setCategria(String categria) {
        this.categria = categria;
    }

    public void mostrarLibro(){
        System.out.println("\nMostrando Libro");
        System.out.println("Título: " + this.getTitulo());
        System.out.println("Autor: " + this.getAutor());
        System.out.println("Nro de Páginas: " + this.getNroPag());
        System.out.println("Precio: " + this.getPrecio());
        System.out.println("Categoría: " + this.getCategria());
    }
}
