package PilaDeCadenas;

import Hito3.PilaNumeros;

import javax.crypto.KeyAgreement;

public class Main {

    public static void main(String[] args) {

        PilaDeCadenas nombresEDD = new PilaDeCadenas(10);

        nombresEDD.adicionar("William");
        nombresEDD.adicionar("Andrés");
        nombresEDD.adicionar("Josias");
        nombresEDD.adicionar("Iris");
        nombresEDD.adicionar("Jonathan");
        nombresEDD.adicionar("Ilia");
        nombresEDD.adicionar("Andrés");

        //nombresEDD.mostrar();
        //DeterminarUsuariosPorNmombre(nombresEDD,"Andrés");
        //AgragarNombre(nombresEDD,"Ana");
        nuevaPosicion(nombresEDD,3);
    }

    //Crear un método en la clase Main cuantos nombres son iguales a ANDRÉS
    public static void DeterminarUsuariosPorNmombre(PilaDeCadenas nombresEDD, String nombreBuscar) {
        PilaDeCadenas aux = new PilaDeCadenas(10);
        int contar = 0;
        String valorExtraidoDeLaPila = "";

        while(nombresEDD.esVacio() == false) {
            valorExtraidoDeLaPila = nombresEDD.eliminar();
            if(valorExtraidoDeLaPila.equals(nombreBuscar) ) {
                contar = contar + 1;
            }
            aux.adicionar(valorExtraidoDeLaPila);
        }
        nombresEDD.vaciar(aux);
        System.out.println("\nCantidad de " + nombreBuscar + " es: " + contar);
    }

    public static void AgragarNombre(PilaDeCadenas NombresEDD, String nombre){
        PilaDeCadenas aux = new PilaDeCadenas(10);
        String valorExtraidoDeLaPila = "";
        while(NombresEDD.esVacio() == false) {
            valorExtraidoDeLaPila = NombresEDD.eliminar();
            aux.adicionar(valorExtraidoDeLaPila);
        }
        NombresEDD.adicionar(nombre);
        NombresEDD.vaciar(aux);
        NombresEDD.mostrar();
    }

    public static void nuevaPosicion(PilaDeCadenas nombresEDD, int kesimo){
        PilaDeCadenas aux = new PilaDeCadenas(10);
        PilaDeCadenas aux2 = new PilaDeCadenas(10);
        String valorExtraidoDeLaPila = "";
        while(nombresEDD.esVacio() == false) {
            if(nombresEDD.nroeElem()!=kesimo) {
                valorExtraidoDeLaPila = nombresEDD.eliminar();
                aux.adicionar(valorExtraidoDeLaPila);
            }else {
                valorExtraidoDeLaPila = nombresEDD.eliminar();
                aux2.adicionar(valorExtraidoDeLaPila);
            }
        }
        nombresEDD.vaciar(aux);
        nombresEDD.vaciar(aux2);
        nombresEDD.mostrar();
    }

}

