package Hito3;

public class PilaNumeros {

    private int max;
    private int[] pilaNums;
    private int tope;

    public PilaNumeros(int max) {
        this.tope = 0;
        this.max =max;
        pilaNums = new int[this.max + 1];
    }

    public boolean esVacio() {
        if(tope == 0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean esllena() {
        if(tope == max) {
            return true;
        } else {
            return false;
        }
    }

    public int nroeElem() {
        return this.tope;
    }

    public void adicionar(int nuevoItem) {
        if(this.esllena() == false) {
            this.tope = this.tope + 1;
            this.pilaNums[this.tope] = nuevoItem;
        } else {
            System.out.println("La Pila de numeros esta llena.");
        }
    }

    public int eliminar() {
        int elementoEliminado =0;
        if(this.esVacio() == false) {
            elementoEliminado = this.pilaNums[this.tope];
            this.tope = this.tope - 1;
        } else {
            System.out.println("La Pila de numeros esta vacia.");
        }
        return elementoEliminado;
    }

    public void llenar() {

    }

    public void mostrar() {
        int elem = 0;
        if(this.esVacio() == true) {
            System.out.println("La Pila de numeros esta vacia.");
        } else {
            System.out.println("Datos de la Pila ");
            PilaNumeros aux = new PilaNumeros(max);
            while(this.esVacio() == false) {
                elem = this.eliminar();
                aux.adicionar(elem);
                System.out.println("Elem: " + elem);
            }
            vaciar(aux);
        }
    }

    public void vaciar (PilaNumeros a) {
        while(a.esVacio() == false){
            adicionar(a.eliminar());
        }
    }

}
