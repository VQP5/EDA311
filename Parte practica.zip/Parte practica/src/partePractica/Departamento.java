package partePractica;

public class Departamento {

    private String nombre;
    private int nroDeProvincias;
    private Provincia[] provincias;

    public Departamento() {
        this.nombre = "";
        this.nroDeProvincias = 0;
        Provincia[] provincias = new Provincia[0];
        this.provincias = provincias;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNroDeProvincias() {
        return nroDeProvincias;
    }

    public void setNroDeProvincias(int nroDeProvincias) {
        this.nroDeProvincias = nroDeProvincias;
    }

    public Provincia[] getProvincias() {
        return provincias;
    }

    public void setProvincias(Provincia[] provincias) {
        this.provincias = provincias;
    }

    public void muestraDepartamento() {
        System.out.println("\nMOSTRANDO DATOS DEL DEPARTAMENTO");
        System.out.println("Nombre del Departamento: " + this.getNombre());
        System.out.println("Número de provincias del Departamento: " + this.getNroDeProvincias());
        for (int i=0; i<this.getProvincias().length; i=i+1) {
            this.getProvincias()[i].muestraProvincia();
        }
    }

}
