package partePractica;

public class Provincia {

    private String nombre;

    public Provincia() {
        this.nombre = "";
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void muestraProvincia() {
        System.out.println("\nMOSTRANDO DATOS DE LA PROVINCIA");
        System.out.println("Nombre de la Provincia: " + this.getNombre());
    }

}