package partePractica;

import java.util.Scanner;

public class Main2 {

    public static void main(String[] args) {

        Scanner leer = new Scanner(System.in);
        String nombreProvincia, nombreDepartamento, nombrePais;
        int numeroProvincias = 2, numeroDepartamentos = 3, numeroPaises = 1;

        Pais paises[] = new Pais[numeroPaises];

        for (int k=0; k<numeroPaises; k=k+1) {
            System.out.println("\nINGRESE DATOS DEL PAÍS");
            System.out.print("Ingrese el nombre del País: ");
            nombrePais = leer.next();
            System.out.print("Ingrese el número de departamentos del País: ");
            numeroDepartamentos = leer.nextInt();

            Departamento departamentos[] = new Departamento[numeroDepartamentos];
            System.out.println("\nINGRESE DATOS DE LOS DEPARTAMENTOS DEL PAÍS " + nombrePais);

            for (int j=0; j<numeroDepartamentos; j=j+1) {
                System.out.print("Ingrese el nombre del Departamento " + (j+1) + ": ");
                nombreDepartamento = leer.next();
                System.out.print("Ingrese el número de provincias del Departamento " + (j+1) + ": ");
                numeroProvincias = leer.nextInt();

                Provincia provincias[] = new Provincia[numeroProvincias];
                System.out.println("\nINGRESE DATOS DE LAS PROVINCIAS DEL DEPARTAMENTO " + nombreDepartamento);

                for (int i=0; i<numeroProvincias; i=i+1) {
                    System.out.print("Ingrese el nombre de la Provincia " + (i+1) + ": ");
                    nombreProvincia = leer.next();

                    Provincia pro = new Provincia();
                    pro.setNombre(nombreProvincia);
                    provincias[i] = pro;
                }

                System.out.println("");
                Departamento dep = new Departamento();
                dep.setNombre(nombreDepartamento);
                dep.setNroDeProvincias(numeroProvincias);
                dep.setProvincias(provincias);
                departamentos[j] = dep;
            }

            Pais p = new Pais();
            p.setNombre(nombrePais);
            p.setNroDeDepartamentos(numeroDepartamentos);
            p.setDepartamentos(departamentos);
            p.muestraPais();
            paises[k] = p;
        }

    }

}
