package partePractica;

import java.util.Scanner;

public class Main1 {

    public static void main(String[] args) {

        Scanner leer = new Scanner(System.in);

//        String nombreProvincia;
//
//        System.out.println("\nINGRESE DATOS DE LA PROVINCIA");
//        System.out.print("Ingrese el nombre de la Provincia: ");
//        nombreProvincia = leer.next();
//
//        Provincia pro = new Provincia();
//        pro.setNombre(nombreProvincia);
//
//        pro.muestraProvincia();

//        String nombreDepartamento;
//        int numeroProvincias;
//
//        System.out.println("\nINGRESE DATOS DEL DEPARTAMENTO");
//        System.out.print("Ingrese el nombre del Departamento: ");
//        nombreDepartamento = leer.next();
//        System.out.print("Ingrese el número de provincias del Departamento: ");
//        numeroProvincias = leer.nextInt();
//
//        Departamento dep = new Departamento();
//        dep.setNombre(nombreDepartamento);
//        dep.setNroDeProvincias(numeroProvincias);
//
//        dep.muestraDepartamento();

        String nombrePais;
        int numeroDepartamentos;

        System.out.println("\nINGRESE DATOS DEL PAÍS");
        System.out.print("Ingrese el nombre del País: ");
        nombrePais = leer.next();
        System.out.print("Ingrese el número de departamentos del País: ");
        numeroDepartamentos = leer.nextInt();

        Pais p = new Pais();
        p.setNombre(nombrePais);
        p.setNroDeDepartamentos(numeroDepartamentos);

        p.muestraPais();

    }

}