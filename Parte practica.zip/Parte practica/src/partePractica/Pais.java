package partePractica;

public class Pais {

    private String nombre;
    private int nroDeDepartamentos;
    private Departamento[] departamentos;

    public Pais() {
        this.nombre = "";
        this.nroDeDepartamentos = 0;
        Departamento[] departamentos = new Departamento[0];
        this.departamentos = departamentos;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNroDeDepartamentos() {
        return nroDeDepartamentos;
    }

    public void setNroDeDepartamentos(int nroDeDepartamentos) {
        this.nroDeDepartamentos = nroDeDepartamentos;
    }

    public Departamento[] getDepartamentos() {
        return departamentos;
    }

    public void setDepartamentos(Departamento[] departamentos) {
        this.departamentos = departamentos;
    }

    public void muestraPais() {
        System.out.println("\nMOSTRANDO DATOS DEL PAÍS");
        System.out.println("Nombre del País: " + this.getNombre());
        System.out.println("Número de departamentos del País: " + this.getNroDeDepartamentos());
        for (int i=0; i<this.getDepartamentos().length; i=i+1) {
            this.getDepartamentos()[i].muestraDepartamento();
        }
    }

}
